import React from 'react';

function Circle(props) {
  return <div className="circle" style={{ ...props }} />;
}

export default Circle;
